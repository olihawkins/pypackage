from pypackage import random

__all__ = [
  "random",
]